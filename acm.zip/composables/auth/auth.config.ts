export const AuthRoutes = [
    '/callback',
    { regex: [/\/profile/.source] }
];