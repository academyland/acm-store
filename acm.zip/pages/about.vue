<template>
  <div>
    <h1>about page</h1>
    <nuxt-link to="/">home</nuxt-link>
  </div>
</template>

<script>
definePageMeta({
  layout: "custom",
});
</script>
