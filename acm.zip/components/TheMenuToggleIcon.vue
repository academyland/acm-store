<template>
  <span class="t-col space-y-[0.4rem]">
    <span class="w-11 h-1 bg-gray-600 rounded-sm" />
    <span class="w-11 h-1 bg-gray-600 rounded-sm" />
    <span class="w-11 h-1 bg-gray-600 rounded-sm" />
  </span>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
    setup () {
        

        return {}
    }
})
</script>

<style scoped>

</style>