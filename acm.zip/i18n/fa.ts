export default {
    messages: {
        login: 'ورود',
        username: 'نام کاربری',
        password: 'کلمه عبور',
        email: 'ایمیل',
        signup: 'ثبت نام',
        first_name: 'نام',
        last_name: 'نام خانوادگی',
        comment: 'نظر',
    }
}