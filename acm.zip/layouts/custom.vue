<template>
  <div>
    <h1>custom</h1>
    <nuxt-page></nuxt-page>
    <footer>footer from layout custom</footer>
  </div>
</template>

<script></script>
