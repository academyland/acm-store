export enum LoginStep {
    login,
    register,
    resetPassword,
}