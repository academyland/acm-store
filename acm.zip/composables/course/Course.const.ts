export const CourseTabs= [
    {id:"about-course",label:"درباره دوره"},
    {id:"requirements-course",label:"پیش نیازهای دوره"},
    {id:"chapters-course",label:"لیست ویدئوها"},
    {id:"faqs-course",label:"پرسش های متداول"},
    {id:"comments-course",label:"نظرات کاربران"},
]